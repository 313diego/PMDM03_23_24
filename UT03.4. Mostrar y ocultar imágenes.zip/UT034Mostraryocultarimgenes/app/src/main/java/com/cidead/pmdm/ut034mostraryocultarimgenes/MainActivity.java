package com.cidead.pmdm.ut034mostraryocultarimgenes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

// Diego Manuel Carrasco Castañares
public class MainActivity extends AppCompatActivity{

    ImageView ivLogo;
    Button btCambiarImg;
    CheckBox cbDesBot;
    RadioGroup rgMosOcuImg;
    RadioButton rbMostrarImg, rbOcultarImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivLogo = (ImageView) findViewById(R.id.ivLogo);
        btCambiarImg = (Button) findViewById(R.id.btCambiarImg);
        cbDesBot = (CheckBox) findViewById(R.id.cbDesBot);
        rgMosOcuImg = (RadioGroup) findViewById(R.id.rgMosOcuImg);
        rbMostrarImg = (RadioButton) findViewById(R.id.rbMostrarImg);
        rbOcultarImg = (RadioButton) findViewById(R.id.rbOcultarImg);

        btCambiarImg.setOnClickListener(new View.OnClickListener() {

            String imagen = "plata";
            @Override
            public void onClick(View v) {

                if (imagen == "plata"){
                    ivLogo.setImageResource(R.drawable.ic_logo_negro);
                    imagen = "negro";
                }else if(imagen == "negro"){
                    ivLogo.setImageResource(R.drawable.ic_logo_act);
                    imagen = "plata";
                }
            }
        });

        cbDesBot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbDesBot.isChecked()){
                    btCambiarImg.setEnabled(true);
                }
                if(!cbDesBot.isChecked()){
                    btCambiarImg.setEnabled(false);
                }
            }
        });

        rbMostrarImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rbMostrarImg.isChecked()){
                    ivLogo.setVisibility(View.VISIBLE);
                }
            }
        });

        rbOcultarImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rbOcultarImg.isChecked()){
                    ivLogo.setVisibility(View.INVISIBLE);
                }
            }
        });

    }
}