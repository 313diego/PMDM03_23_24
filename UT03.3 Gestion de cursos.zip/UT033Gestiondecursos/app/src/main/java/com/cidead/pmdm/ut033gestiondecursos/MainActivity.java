package com.cidead.pmdm.ut033gestiondecursos;

import static com.cidead.pmdm.ut033gestiondecursos.R.id.selectCurso;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

// Diego Manuel Carrasco Castañares
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    RadioButton rbPhp, rbJava, rbC;
    RadioGroup rgCursos;
    CheckBox cbFamNum, cbSocOro;
    Button btCalcular;
    double dtoTotal, impTotal;
    final double php = 120;
    final double java = 100;
    final double c = 90;
    final double dtoFamNum = 0.1;
    final double dtoSocio = 0.05;
    String curso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rbPhp = (RadioButton) findViewById(R.id.rbPhp);
        rbJava = (RadioButton) findViewById(R.id.rbJava);
        rbC = (RadioButton) findViewById(R.id.rbC);

        rgCursos = (RadioGroup) findViewById(R.id.rgCursos);

        cbFamNum = (CheckBox) findViewById(R.id.cbFamNum);
        cbSocOro = (CheckBox) findViewById(R.id.cbSocOro);

        btCalcular = (Button) findViewById(R.id.btCalcular);

        btCalcular.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (cbFamNum.isChecked()){
            dtoTotal = dtoFamNum;
        }
        if (cbSocOro.isChecked()){
            dtoTotal = dtoSocio;
        }
        if (cbFamNum.isChecked() && cbSocOro.isChecked()){
            dtoTotal = dtoSocio + dtoFamNum;
        }

        if (!cbFamNum.isChecked() && !cbSocOro.isChecked())
            dtoTotal = 0;

        if (rbPhp.isChecked()){
            impTotal = php - (php * dtoTotal);
            curso = getResources().getString(R.string.php_120);
        } else if (rbJava.isChecked()) {
            impTotal = java - (java * dtoTotal);
            curso = getResources().getString(R.string.java_100);
        } else if (rbC.isChecked()) {
            impTotal = c - (c * dtoTotal);
            curso = getResources().getString(R.string.c_90);
        }

        if(curso != null) {
            String mensaje = getString(R.string.curso_seleccionado) + curso + getString(R.string.imp_pagar)
                    + impTotal + "€";
            Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
        }else{
            String mensaje = getString(R.string.curso_no_select);
            Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
        }

    }

}