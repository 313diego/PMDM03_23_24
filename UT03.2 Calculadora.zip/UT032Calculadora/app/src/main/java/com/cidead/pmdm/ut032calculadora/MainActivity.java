package com.cidead.pmdm.ut032calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// Diego Manuel Carrasco Castañares
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView tvResultado;
    EditText etOperando1;
    EditText etOperando2;
    Button btSumar, btRestar, btMulti, btDiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvResultado = (TextView) findViewById(R.id.tvResultado);
        etOperando1 = (EditText) findViewById(R.id.etOperando1);
        etOperando2 = (EditText) findViewById(R.id.etOperando2);
        btSumar = (Button) findViewById(R.id.btSumar);
        btSumar.setOnClickListener(this);
        btRestar = (Button) findViewById(R.id.btRestar);
        btRestar.setOnClickListener(this);
        btMulti = (Button) findViewById(R.id.btMulti);
        btMulti.setOnClickListener(this);
        btDiv = (Button) findViewById(R.id.btDiv);
        btDiv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        Double operando1 = Double.parseDouble(etOperando1.getText().toString());
        Double operando2 = Double.parseDouble(etOperando2.getText().toString());
        Double dSuma, dResta, dMulti, dDiv;
        String suma, resta, multi, div;
        int id = v.getId();

        if (id == R.id.btSumar){
            dSuma = operando1 + operando2;
            suma = String.valueOf(dSuma);
            tvResultado.setText(suma);
        }else if (id == R.id.btRestar){
            dResta = operando1 - operando2;
            resta = String.valueOf(dResta);
            tvResultado.setText(resta);
        }else if (id == R.id.btMulti){
            dMulti = operando1 * operando2;
            multi = String.valueOf(dMulti);
            tvResultado.setText(multi);
        }else if (id == R.id.btDiv){
            if(operando2 > 0) {
                dDiv = operando1 / operando2;
                div = String.valueOf(dDiv);
                tvResultado.setText(div);
            }else{
                String mensaje = getResources().getString(R.string.ex);
                tvResultado.setText("");
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
            }
        }
    }
}