package com.cidead.pmdm.ut031mostardatospersonles;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// Diego Manuel Carrasco Castañares

public class MainActivity extends AppCompatActivity{

    EditText etNombre, etEmail, etTlf;
    Button btMostrar;
    TextView tvMostrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNombre = (EditText) findViewById(R.id.etNombre);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etTlf = (EditText) findViewById(R.id.etTlf);

        btMostrar = (Button) findViewById(R.id.btMostrar);

        tvMostrar = (TextView) findViewById(R.id.tvMostrar);

        btMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etNombre.getText().toString().isEmpty() || etEmail.getText().toString().isEmpty()
                || etTlf.getText().toString().isEmpty()){
                    String mensaje = getResources().getString(R.string.mensaje);
                    Toast.makeText(MainActivity.this, mensaje, Toast.LENGTH_LONG).show();;
                }else{
                    tvMostrar.setText(etNombre.getText().toString() + "\n" + etEmail.getText()
                            .toString() + "\n" + etTlf.getText().toString());
                }
            }
        });


    }
}